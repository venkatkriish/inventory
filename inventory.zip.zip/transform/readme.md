The transform scripts convert multiple JSON files into a unified JSON file containing all the data for the subscription.
